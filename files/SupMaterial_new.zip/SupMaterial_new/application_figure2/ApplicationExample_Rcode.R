# jonashaslbeck@gmail.com

# -----------------------------------------------------------------------------------------------
# ---------- Load Data --------------------------------------------------------------------------
# -----------------------------------------------------------------------------------------------

dataDir # <- '.../' Specify directory which contains Fried2015.RDS
figDir <- # Specify directory in which the figure should be saved

  data_list <- readRDS(paste0(dataDir, 'Fried2015.RDS'))


# -----------------------------------------------------------------------------------------------
# ---------- Estimate MGM & Compute Errors ------------------------------------------------------
# -----------------------------------------------------------------------------------------------

library(mgm) # version 1.2-0

# ---------- a) Fit MGM ----------

set.seed(1)
fit <- mgm(data = data_list$data, 
                type = data_list$type,
                level = data_list$lev,
                ruleReg = 'AND',
                k = 2, 
                binarySign = TRUE, 
                overparameterize = FALSE)

# ---------- b) Make Predictions / Compute Nodewise Errors ----------

pred <- predict(fit, data_list$data)
pred$errors

mean(pred$errors[,3]) # mean predictability
round(1-mean(data_list$data[,6]), 2) # marginal of 'unfr'


# -----------------------------------------------------------------------------------------------
# ---------- Plot Figure 2 ----------------------------------------------------------------------
# -----------------------------------------------------------------------------------------------

library(qgraph)
data_list$names[12] <- 'loss'

pdf(paste0(figDir, 'Fig2_Fried2015_Network_Binary_new.pdf'), width = 12, height = 8)
qgraph(fit$pairwise$wadj, pie=pred$errors[,3], layout='spring', 
       labels = data_list$names, 
       pieColor = '#377EB8', label.cex = .9, cut = 0, 
       edge.color = fit$pairwise$edgecolor)
dev.off()


# -----------------------------------------------------------------------------------------------
# ---------- Plot Figure 2 (grey version) -------------------------------------------------------
# -----------------------------------------------------------------------------------------------

pdf(paste0(figDir, 'Fig2_Fried2015_Network_Binary_bw_new.pdf'), width = 12, height = 8)
qgraph(fit$pairwise$wadj, pie=pred$errors[,3], layout='spring', 
       labels = data_list$names, 
       pieColor = 'darkgrey', label.cex = .9, cut = 0, 
       edge.color = 'black')
dev.off()




